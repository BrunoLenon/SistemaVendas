"""Blueprints do SistemaVendas.

Mantemos os blueprints em módulos separados para reduzir o tamanho do app.py
e facilitar manutenção.
"""
