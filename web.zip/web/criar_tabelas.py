from db import criar_tabelas

criar_tabelas()
print("✅ Tabelas criadas com sucesso")
